Add Mr Banji's portrait here as banji-alabi.jpg (or .png / .webp). It appears on Home, About and Team.
Team members: add photos named after their slug in lib/team.ts, e.g. associate-one.jpg.
