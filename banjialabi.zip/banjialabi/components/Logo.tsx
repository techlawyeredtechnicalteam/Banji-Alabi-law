import { firstExisting } from "@/lib/assets";
import { site } from "@/lib/site";

/**
 * Uses the firm's own logo, untouched. Drop it in /public as logo.svg, logo.png or logo.webp.
 * Optional: logo-light.(svg|png|webp) is used on dark backgrounds if present.
 */
export default function Logo({ onDark = false, height = 48 }: { onDark?: boolean; height?: number }) {
  const main = firstExisting(["logo.svg", "logo.png", "logo.webp", "logo.jpg", "images/logo.svg", "images/logo.png"]);
  const light = firstExisting(["logo-light.svg", "logo-light.png", "logo-light.webp"]);

  if (main) {
    const src = onDark && light ? light : main;
    const needsPlate = onDark && !light;
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt={`${site.name} logo`}
        style={{ height, width: "auto" }}
        className={needsPlate ? "rounded-sm bg-paper p-2" : ""}
      />
    );
  }

  // Temporary wordmark until the logo file is added.
  return (
    <span className="flex items-center gap-3">
      <span
        className="grid place-items-center border border-brass font-display text-lg text-brass"
        style={{ height, width: height }}
        aria-hidden="true"
      >
        BA
      </span>
      <span className={`font-display text-xl leading-none ${onDark ? "text-paper" : "text-ink"}`}>
        {site.name}
      </span>
    </span>
  );
}
