"use client";

import { useState, type FormEvent } from "react";

const areas = [
  "Real estate and conveyancing",
  "Estates and plots (Metro Smart City, Nicon Town, Lekki, Victoria Island, Ikoyi)",
  "Litigation and alternative dispute resolution",
  "Maritime and shipping",
  "Aviation law",
  "Banking and project finance",
  "Investment law",
  "Tax and revenue consultancy",
  "Oil and gas advisory",
  "Labour and employment",
  "Immigration",
  "Intellectual property",
  "Other",
];

type Errors = Partial<Record<"name" | "email" | "phone" | "message" | "consent", string>>;

export default function EnquiryForm({ defaultArea = "" }: { defaultArea?: string }) {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [errors, setErrors] = useState<Errors>({});
  const [serverMsg, setServerMsg] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form)) as Record<string, string>;
    data.consent = (form.elements.namedItem("consent") as HTMLInputElement).checked ? "yes" : "";

    setStatus("sending");
    setErrors({});
    setServerMsg("");

    try {
      const res = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json().catch(() => ({}));
      if (res.ok) {
        setStatus("sent");
        form.reset();
        return;
      }
      if (json.errors) setErrors(json.errors);
      setServerMsg(json.message ?? "We could not send your enquiry. Please call or message us on WhatsApp.");
      setStatus("error");
    } catch {
      setServerMsg("We could not reach the server. Please check your connection or call us.");
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <div role="status" className="border border-brass bg-limestone/70 p-8">
        <h2 className="text-3xl">Thank you. We have your enquiry.</h2>
        <p className="mt-3 max-w-md text-muted">
          A member of our team will reply by email or phone, usually within one working day. If your matter is urgent, call or message us on WhatsApp.
        </p>
        <button type="button" className="btn btn-outline-ink mt-6" onClick={() => setStatus("idle")}>
          Send another enquiry
        </button>
      </div>
    );
  }

  const err = (k: keyof Errors) =>
    errors[k] ? (
      <p id={`${k}-err`} className="mt-1.5 text-sm text-[#a3281f]">
        {errors[k]}
      </p>
    ) : null;

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5" aria-describedby={serverMsg ? "form-err" : undefined}>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="mb-1.5 block text-sm font-semibold">Full name</label>
          <input id="name" name="name" autoComplete="name" required className="field" aria-invalid={!!errors.name} aria-describedby={errors.name ? "name-err" : undefined} />
          {err("name")}
        </div>
        <div>
          <label htmlFor="phone" className="mb-1.5 block text-sm font-semibold">Phone number</label>
          <input id="phone" name="phone" type="tel" autoComplete="tel" className="field" aria-invalid={!!errors.phone} aria-describedby={errors.phone ? "phone-err" : undefined} />
          {err("phone")}
        </div>
      </div>

      <div>
        <label htmlFor="email" className="mb-1.5 block text-sm font-semibold">Email address</label>
        <input id="email" name="email" type="email" autoComplete="email" required className="field" aria-invalid={!!errors.email} aria-describedby={errors.email ? "email-err" : undefined} />
        {err("email")}
      </div>

      <div>
        <label htmlFor="area" className="mb-1.5 block text-sm font-semibold">What do you need help with?</label>
        <select id="area" name="area" defaultValue={defaultArea} className="field">
          <option value="">Choose a practice area</option>
          {areas.map((a) => (
            <option key={a} value={a}>{a}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="message" className="mb-1.5 block text-sm font-semibold">Briefly describe your matter</label>
        <textarea id="message" name="message" rows={6} required className="field" aria-invalid={!!errors.message} aria-describedby={errors.message ? "message-err" : undefined} />
        {err("message")}
      </div>

      {/* Honeypot: real visitors never see or fill this */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label>
          Website
          <input name="website" tabIndex={-1} autoComplete="off" />
        </label>
      </div>

      <div>
        <label className="flex items-start gap-3 text-[0.95rem]">
          <input type="checkbox" name="consent" className="mt-1.5 h-4 w-4 accent-[#7d5a1c]" />
          <span>
            I understand that sending this form does not create a lawyer-client relationship, and I agree that Banji Alabi &amp; Co may contact me about my enquiry.
          </span>
        </label>
        {err("consent")}
      </div>

      {serverMsg && (
        <p id="form-err" role="alert" className="border-l-4 border-[#a3281f] bg-[#a3281f]/5 p-3 text-[0.95rem]">
          {serverMsg}
        </p>
      )}

      <button type="submit" disabled={status === "sending"} className="btn btn-ink disabled:opacity-60">
        {status === "sending" ? "Sending…" : "Send enquiry"}
      </button>
    </form>
  );
}
