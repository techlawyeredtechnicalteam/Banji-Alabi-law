import Link from "next/link";
import Logo from "./Logo";
import { site, nav } from "@/lib/site";
import { practiceAreas } from "@/lib/practice-areas";

export default function Footer() {
  return (
    <footer className="bg-ink text-paper/80">
      <div className="wrap grid gap-12 py-16 md:grid-cols-12">
        <div className="md:col-span-5">
          <Logo onDark height={52} />
          <p className="mt-6 max-w-sm text-[0.97rem] text-paper/70">
            Legal practitioners advising on real estate and conveyancing, litigation, banking, aviation, maritime and corporate law.
          </p>
        </div>

        <div className="md:col-span-2">
          <h2 className="font-sans text-sm font-semibold text-paper">Explore</h2>
          <ul className="mt-4 space-y-2.5 text-[0.95rem]">
            {nav.map((n) => (
              <li key={n.href}>
                <Link href={n.href} className="hover:text-brass-light">{n.label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-2">
          <h2 className="font-sans text-sm font-semibold text-paper">Practice areas</h2>
          <ul className="mt-4 space-y-2.5 text-[0.95rem]">
            {practiceAreas.map((p) => (
              <li key={p.slug}>
                <Link href={`/practice-areas/${p.slug}`} className="hover:text-brass-light">{p.title}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-3">
          <h2 className="font-sans text-sm font-semibold text-paper">Contact</h2>
          <ul className="mt-4 space-y-2.5 text-[0.95rem]">
            <li><a href={site.phoneHref} className="hover:text-brass-light">{site.phone}</a></li>
            <li><a href={`mailto:${site.email}`} className="break-all hover:text-brass-light">{site.email}</a></li>
            {site.address && <li>{site.address}</li>}
            <li className="text-paper/60">{site.hours}</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-paper/10">
        <div className="wrap flex flex-col gap-2 py-6 text-[0.85rem] text-paper/55 md:flex-row md:justify-between">
          <p>&copy; {new Date().getFullYear()} {site.name}. All rights reserved.</p>
          <p className="max-w-xl">
            The information on this website is general and is not legal advice. Visiting it does not create a lawyer-client relationship.
          </p>
        </div>
      </div>
    </footer>
  );
}
