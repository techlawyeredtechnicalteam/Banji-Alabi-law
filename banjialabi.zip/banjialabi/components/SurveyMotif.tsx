/**
 * A stylised survey plan: parcel boundaries, numbered beacons and bearings.
 * Purely decorative.
 */
export default function SurveyMotif({ className = "" }: { className?: string }) {
  const stroke = "var(--color-brass-light)";
  return (
    <svg
      viewBox="0 0 560 520"
      role="presentation"
      aria-hidden="true"
      className={className}
      fill="none"
    >
      {/* faint grid */}
      <g stroke="rgb(250 248 244 / 0.06)" strokeWidth="1">
        {[80, 160, 240, 320, 400, 480].map((x) => (
          <line key={"v" + x} x1={x} y1="0" x2={x} y2="520" />
        ))}
        {[80, 160, 240, 320, 400, 480].map((y) => (
          <line key={"h" + y} x1="0" y1={y} x2="560" y2={y} />
        ))}
      </g>

      {/* main parcel */}
      <polygon
        className="survey-line d1"
        pathLength="1"
        points="92,150 400,96 478,300 330,430 140,380"
        stroke={stroke}
        strokeWidth="2"
        strokeLinejoin="round"
      />
      {/* subdivision lines */}
      <path
        className="survey-line d2"
        pathLength="1"
        d="M246 123 L234 405"
        stroke={stroke}
        strokeWidth="1.2"
        strokeDasharray="1"
      />
      <path
        className="survey-line d2"
        pathLength="1"
        d="M246 262 L452 214"
        stroke={stroke}
        strokeWidth="1.2"
      />
      {/* neighbouring plot */}
      <polygon
        className="survey-line d3"
        pathLength="1"
        points="400,96 520,70 548,214 478,300"
        stroke="rgb(250 248 244 / 0.4)"
        strokeWidth="1.2"
      />
      <path
        className="survey-line d3"
        pathLength="1"
        d="M20 470 C 150 430, 260 500, 390 470 S 520 440, 548 450"
        stroke="rgb(250 248 244 / 0.25)"
        strokeWidth="1.2"
      />

      {/* beacons */}
      {[
        { x: 92, y: 150, l: "B1", dx: -34, dy: -8 },
        { x: 400, y: 96, l: "B2", dx: 10, dy: -12 },
        { x: 478, y: 300, l: "B3", dx: 12, dy: 6 },
        { x: 330, y: 430, l: "B4", dx: 10, dy: 22 },
        { x: 140, y: 380, l: "B5", dx: -34, dy: 20 },
      ].map((b, i) => (
        <g
          key={b.l}
          className="survey-beacon"
          style={{ animationDelay: `${1.4 + i * 0.18}s` }}
        >
          <circle cx={b.x} cy={b.y} r="6" fill="var(--color-ink)" stroke={stroke} strokeWidth="2" />
          <circle cx={b.x} cy={b.y} r="2" fill={stroke} />
          <text
            x={b.x + b.dx}
            y={b.y + b.dy}
            fill="var(--color-brass-light)"
            fontSize="13"
            fontFamily="var(--font-sans)"
            fontWeight="600"
          >
            {b.l}
          </text>
        </g>
      ))}

      {/* bearings */}
      <g
        className="survey-beacon"
        style={{ animationDelay: "2.3s" }}
        fill="rgb(250 248 244 / 0.6)"
        fontSize="11.5"
        fontFamily="var(--font-sans)"
      >
        <text x="214" y="104" transform="rotate(-9 214 104)">N 80°12′ E  311.40 m</text>
        <text x="468" y="190" transform="rotate(68 468 190)">S 22°40′ E  218.75 m</text>
        <text x="190" y="440" transform="rotate(-27 190 440)">S 61°05′ W  172.10 m</text>
        <text x="40" y="262" transform="rotate(84 40 262)">N 10°30′ W  232.60 m</text>
      </g>

      {/* north arrow */}
      <g transform="translate(60 70)" className="survey-beacon" style={{ animationDelay: "2.5s" }}>
        <path d="M0 22 L8 -8 L16 22 L8 15 Z" fill="none" stroke={stroke} strokeWidth="1.5" strokeLinejoin="round" />
        <text x="3" y="42" fill="var(--color-brass-light)" fontSize="13" fontWeight="600" fontFamily="var(--font-sans)">N</text>
      </g>
    </svg>
  );
}
