import { whatsappLink } from "@/lib/site";
import { WhatsAppIcon } from "./Icons";

export default function WhatsAppButton() {
  return (
    <a
      href={whatsappLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 rounded-full bg-[#1fa855] px-4 py-3 text-white shadow-lg shadow-black/25 transition-transform hover:scale-[1.03] md:bottom-7 md:right-7"
    >
      <WhatsAppIcon size={26} />
      <span className="hidden text-[0.95rem] font-semibold md:inline">Chat on WhatsApp</span>
    </a>
  );
}
