import type { ReactNode } from "react";

export default function PageHeader({
  title,
  intro,
  children,
}: {
  title: string;
  intro?: string;
  children?: ReactNode;
}) {
  return (
    <section className="bg-ink text-paper">
      <div className="wrap py-16 md:py-24">
        <h1 className="max-w-3xl text-[2.5rem] md:text-[3.75rem]">{title}</h1>
        {intro && <p className="mt-6 max-w-2xl text-lg text-paper/75">{intro}</p>}
        {children && <div className="mt-8">{children}</div>}
      </div>
    </section>
  );
}
