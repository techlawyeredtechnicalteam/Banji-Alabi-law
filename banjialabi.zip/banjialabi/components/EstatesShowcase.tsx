import Link from "next/link";
import { whatsappLink, site } from "@/lib/site";
import { WhatsAppIcon, PhoneIcon } from "./Icons";

const locations = [
  { name: "Metro Smart City", note: "Flexible payment plan available" },
  { name: "Nicon Town Estate", note: "Gated estate, Lekki" },
  { name: "Admiralty Way, Lekki 1", note: "Prime Lekki address" },
  { name: "Victoria Island", note: "Prime plots and luxury homes" },
  { name: "Ikoyi", note: "Prime plots and luxury homes" },
];

const assurances = [
  "Titles verified before you pay",
  "Fully secured and gated estates",
  "Prime locations",
  "Flexible payment plan at Metro Smart City",
  "High-return investment potential",
];

export default function EstatesShowcase() {
  return (
    <section className="bg-ink py-20 text-paper md:py-28" aria-labelledby="estates-h">
      <div className="wrap">
        <p className="max-w-2xl font-display text-2xl italic text-brass-light md:text-3xl">
          In Polo, you don&apos;t follow the crowd. You lead it.
        </p>
        <h2 id="estates-h" className="mt-6 max-w-3xl text-4xl md:text-6xl">
          Prime plots and luxury homes. Verified titles. Secured estates.
        </h2>
        <p className="mt-6 max-w-2xl text-lg text-paper/75">
          Banji Alabi, Esq. invites you to own property in the addresses where Lagos&apos;s leaders live, invest and build.
        </p>

        <ul className="mt-12 grid gap-px bg-paper/15 sm:grid-cols-2 lg:grid-cols-3">
          {locations.map((l) => (
            <li key={l.name} className="bg-ink">
              <div className="grid aspect-[4/3] place-items-center border-b border-paper/10 bg-navy text-sm text-paper/40">
                Photograph to be added
              </div>
              <div className="p-5">
                <h3 className="text-2xl">{l.name}</h3>
                <p className="mt-1 text-[0.95rem] text-paper/65">{l.note}</p>
              </div>
            </li>
          ))}
        </ul>

        <ul className="mt-12 grid gap-3 md:grid-cols-2">
          {assurances.map((a) => (
            <li key={a} className="flex items-start gap-3 text-lg">
              <span className="mt-2.5 h-2 w-2 shrink-0 bg-brass" aria-hidden="true" />
              {a}
            </li>
          ))}
        </ul>

        <div className="mt-12 flex flex-wrap items-center gap-3">
          <a href={whatsappLink("Hello Mr Alabi, I am interested in your plots and homes.")} target="_blank" rel="noopener noreferrer" className="btn btn-brass">
            <WhatsAppIcon size={18} /> Private chat on WhatsApp
          </a>
          <a href={site.phoneHref} className="btn btn-outline-light"><PhoneIcon /> {site.phone}</a>
          <Link href="/contact?area=Estates%20and%20plots%20(Metro%20Smart%20City%2C%20Nicon%20Town%2C%20Lekki%2C%20Victoria%20Island%2C%20Ikoyi)" className="btn btn-outline-light">Send an enquiry</Link>
        </div>
        <p className="mt-6 max-w-2xl text-sm text-paper/55">
          Availability, prices and payment plans are confirmed in writing. Property transaction costs are separate from our conveyancing fees.
        </p>
      </div>
    </section>
  );
}
