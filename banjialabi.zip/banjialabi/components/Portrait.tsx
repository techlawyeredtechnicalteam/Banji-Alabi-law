import { firstExisting } from "@/lib/assets";

export default function Portrait({
  file = "banji-alabi",
  name = "Banji Alabi",
  className = "",
}: {
  file?: string;
  name?: string;
  className?: string;
}) {
  const base = file.replace(/\.[a-z]+$/i, "");
  const src = firstExisting([
    `images/${base}.jpg`,
    `images/${base}.jpeg`,
    `images/${base}.png`,
    `images/${base}.webp`,
  ]);
  const initials = name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("");

  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={src} alt={`Portrait of ${name}`} className={`object-cover object-top ${className}`} />
    );
  }
  return (
    <div className={`grid place-items-center bg-navy text-brass-light ${className}`} role="img" aria-label={`Portrait of ${name} to be added`}>
      <span className="font-display text-6xl">{initials}</span>
    </div>
  );
}
