"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { nav, site } from "@/lib/site";
import { PhoneIcon, MailIcon } from "./Icons";

const labels: Record<string, string> = {
  "/about": "About",
  "/real-estate-conveyancing": "Real estate & conveyancing",
};

export default function Header({ logo }: { logo: ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/95 backdrop-blur">
      <div className="hidden bg-ink text-[0.82rem] text-paper/80 md:block">
        <div className="wrap flex items-center justify-between py-2">
          <span>{site.tagline}</span>
          <div className="flex items-center gap-6">
            <a href={site.phoneHref} className="flex items-center gap-2 hover:text-brass-light">
              <PhoneIcon size={14} /> {site.phone}
            </a>
            <a href={`mailto:${site.email}`} className="flex items-center gap-2 hover:text-brass-light">
              <MailIcon size={14} /> {site.email}
            </a>
          </div>
        </div>
      </div>

      <div className="wrap flex items-center justify-between gap-6 py-3">
        <Link href="/" aria-label={`${site.name}, home`} className="shrink-0">
          {logo}
        </Link>

        <nav aria-label="Main" className="hidden items-center gap-7 xl:flex">
          {nav.map((item) =>
            item.href === "/contact" ? (
              <Link key={item.href} href={item.href} className="btn btn-ink !py-2.5">
                Make an enquiry
              </Link>
            ) : (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive(item.href) ? "page" : undefined}
                className={`relative text-[0.95rem] font-medium transition-colors hover:text-brass-deep ${
                  isActive(item.href) ? "text-brass-deep" : "text-ink"
                }`}
              >
                {labels[item.href] ?? item.label}
                {isActive(item.href) && (
                  <span className="absolute -bottom-2 left-0 h-0.5 w-full bg-brass" />
                )}
              </Link>
            ),
          )}
        </nav>

        <button
          type="button"
          className="grid h-11 w-11 place-items-center border border-ink/20 xl:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((o) => !o)}
        >
          <span className="relative block h-3.5 w-5">
            <span className={`absolute left-0 top-0 h-0.5 w-5 bg-ink transition-transform ${open ? "translate-y-[6px] rotate-45" : ""}`} />
            <span className={`absolute left-0 top-[6px] h-0.5 w-5 bg-ink transition-opacity ${open ? "opacity-0" : ""}`} />
            <span className={`absolute left-0 top-[12px] h-0.5 w-5 bg-ink transition-transform ${open ? "-translate-y-[6px] -rotate-45" : ""}`} />
          </span>
        </button>
      </div>

      {open && (
        <div id="mobile-menu" className="absolute inset-x-0 top-full max-h-[calc(100dvh-5rem)] overflow-y-auto bg-ink text-paper xl:hidden">
          <nav aria-label="Mobile" className="wrap flex flex-col py-6">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`border-b border-paper/10 py-4 font-display text-2xl ${
                  isActive(item.href) ? "text-brass-light" : "text-paper"
                }`}
              >
                {item.href === "/contact" ? "Make an enquiry" : item.label}
              </Link>
            ))}
            <div className="mt-8 flex flex-col gap-3 text-paper/80">
              <a href={site.phoneHref} className="flex items-center gap-3"><PhoneIcon /> {site.phone}</a>
              <a href={`mailto:${site.email}`} className="flex items-center gap-3"><MailIcon /> {site.email}</a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
