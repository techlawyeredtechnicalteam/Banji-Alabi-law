import { listMedia } from "@/lib/assets";

export default function MediaGallery({ folder, limit }: { folder: string; limit?: number }) {
  const all = listMedia(folder);
  const items = limit ? all.slice(0, limit) : all;

  if (items.length === 0) {
    return (
      <div className="grid gap-4 sm:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="grid aspect-[4/3] place-items-center border border-dashed border-ink/25 bg-limestone/60 p-6 text-center text-sm text-muted"
          >
            {i === 0
              ? "Photographs and videos of our properties and sites will appear here."
              : "Property photograph"}
          </div>
        ))}
        {process.env.NODE_ENV !== "production" && (
          <p className="text-sm text-muted sm:col-span-3">
            Add images (.jpg, .png, .webp) or videos (.mp4, .webm) to <code>public/media/{folder}/</code> and they show up here automatically.
          </p>
        )}
      </div>
    );
  }

  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((m) => (
        <li key={m.src} className="overflow-hidden bg-limestone">
          {m.type === "image" ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={m.src} alt="" loading="lazy" className="aspect-[4/3] w-full object-cover" />
          ) : (
            <video
              src={m.src}
              controls
              preload="metadata"
              playsInline
              className="aspect-[4/3] w-full bg-ink object-cover"
            />
          )}
        </li>
      ))}
    </ul>
  );
}
