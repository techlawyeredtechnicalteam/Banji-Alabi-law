import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import EnquiryForm from "@/components/EnquiryForm";
import { PhoneIcon, MailIcon, WhatsAppIcon } from "@/components/Icons";
import { site, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact and enquiries",
  description: "Call, email or message Banji Alabi & Co on WhatsApp, or send an enquiry online.",
};

type Props = { searchParams: Promise<{ area?: string }> };

export default async function Contact({ searchParams }: Props) {
  const { area } = await searchParams;

  return (
    <>
      <PageHeader
        title="Contact us"
        intro="Tell us briefly about your matter and we will reply, usually within one working day."
      />
      <section className="py-16 md:py-20">
        <div className="wrap grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <EnquiryForm defaultArea={area ?? ""} />
          </div>

          <aside className="lg:col-span-5">
            <h2 className="text-3xl">Reach us directly</h2>
            <ul className="mt-6 space-y-5">
              <li>
                <a href={site.phoneHref} className="flex items-center gap-4 hover:text-brass-deep">
                  <span className="grid h-11 w-11 place-items-center bg-ink text-paper"><PhoneIcon /></span>
                  <span>
                    <span className="block text-sm text-muted">Phone</span>
                    <span className="font-semibold">{site.phone}</span>
                  </span>
                </a>
              </li>
              <li>
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 hover:text-brass-deep">
                  <span className="grid h-11 w-11 place-items-center bg-[#1fa855] text-white"><WhatsAppIcon size={20} /></span>
                  <span>
                    <span className="block text-sm text-muted">WhatsApp</span>
                    <span className="font-semibold">{site.phone}</span>
                  </span>
                </a>
              </li>
              <li>
                <a href={`mailto:${site.email}`} className="flex items-center gap-4 hover:text-brass-deep">
                  <span className="grid h-11 w-11 place-items-center bg-ink text-paper"><MailIcon /></span>
                  <span>
                    <span className="block text-sm text-muted">Email</span>
                    <span className="break-all font-semibold">{site.email}</span>
                  </span>
                </a>
              </li>
            </ul>

            <div className="mt-10 border-t border-ink/15 pt-6 text-muted">
              {site.address && <p className="mb-3">{site.address}</p>}
              <p>{site.hours}</p>
              <p className="mt-6 text-sm">
                Please do not send confidential documents through this form. We will tell you how to share them securely once we have spoken.
              </p>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
