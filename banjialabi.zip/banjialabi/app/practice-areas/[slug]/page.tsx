import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PageHeader from "@/components/PageHeader";
import { getPracticeArea, practiceAreas } from "@/lib/practice-areas";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return practiceAreas.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const area = getPracticeArea(slug);
  return area ? { title: area.title, description: area.summary } : {};
}

export default async function PracticeAreaPage({ params }: Props) {
  const { slug } = await params;
  const area = getPracticeArea(slug);
  if (!area) notFound();

  return (
    <>
      <PageHeader title={area.title} intro={area.summary} />
      <section className="py-16 md:py-20">
        <div className="wrap grid gap-12 lg:grid-cols-12">
          <div className="prose-legal text-lg text-muted lg:col-span-7">
            <p>{area.intro}</p>
          </div>
          <div className="lg:col-span-5">
            <h2 className="text-2xl">What we handle</h2>
            <ul className="mt-5 divide-y divide-ink/15 border-y border-ink/15">
              {area.services.map((s) => (
                <li key={s} className="py-3">{s}</li>
              ))}
            </ul>
            <Link
              href={`/contact?area=${encodeURIComponent(area.title)}`}
              className="btn btn-ink mt-8"
            >
              Enquire about this area
            </Link>
          </div>
        </div>
      </section>
      <section className="border-t border-ink/10 py-12">
        <div className="wrap">
          <Link href="/practice-areas" className="font-semibold text-brass-deep hover:underline">
            Back to all practice areas
          </Link>
        </div>
      </section>
    </>
  );
}
