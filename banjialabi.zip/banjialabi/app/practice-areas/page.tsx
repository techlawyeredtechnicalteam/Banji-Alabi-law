import type { Metadata } from "next";
import Link from "next/link";
import PageHeader from "@/components/PageHeader";
import { practiceAreas } from "@/lib/practice-areas";
import { ChevronRight } from "@/components/Icons";

export const metadata: Metadata = {
  title: "Practice areas",
  description: "Litigation, banking, aviation, maritime, corporate, probate and employment law, alongside our real estate and conveyancing practice.",
};

export default function PracticeAreas() {
  return (
    <>
      <PageHeader
        title="Practice areas"
        intro="Ten areas of practice, supported by a dedicated real estate and conveyancing practice."
      />

      <section className="py-16 md:py-20">
        <div className="wrap">
          <ul className="grid gap-px bg-ink/15 md:grid-cols-2">
            {practiceAreas.map((p) => (
              <li key={p.slug} className="bg-paper">
                <Link href={`/practice-areas/${p.slug}`} className="group flex h-full flex-col p-8 hover:bg-limestone/60">
                  <h2 className="text-3xl">{p.title}</h2>
                  <p className="mt-3 flex-1 text-muted">{p.summary}</p>
                  <span className="mt-6 inline-flex items-center gap-1 font-semibold text-brass-deep">
                    Read more <ChevronRight size={16} />
                  </span>
                </Link>
              </li>
            ))}
          </ul>

          <div className="mt-12 flex flex-col items-start justify-between gap-6 bg-ink p-8 text-paper md:flex-row md:items-center md:p-10">
            <div>
              <h2 className="text-3xl">Real estate and conveyancing</h2>
              <p className="mt-2 max-w-lg text-paper/70">Our dedicated property practice has its own page, with details of how we handle transactions and how our fees work.</p>
            </div>
            <Link href="/real-estate-conveyancing" className="btn btn-brass">View property practice</Link>
          </div>
        </div>
      </section>
    </>
  );
}
