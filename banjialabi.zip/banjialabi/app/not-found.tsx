import Link from "next/link";

export default function NotFound() {
  return (
    <section className="wrap py-28">
      <h1 className="text-5xl">This page could not be found.</h1>
      <p className="mt-4 max-w-md text-muted">The link may be out of date. Return to the home page or contact us directly.</p>
      <div className="mt-8 flex gap-3">
        <Link href="/" className="btn btn-ink">Go to home page</Link>
        <Link href="/contact" className="btn btn-outline-ink">Contact us</Link>
      </div>
    </section>
  );
}
