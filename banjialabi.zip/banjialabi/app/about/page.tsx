import type { Metadata } from "next";
import Link from "next/link";
import PageHeader from "@/components/PageHeader";
import Portrait from "@/components/Portrait";

export const metadata: Metadata = {
  title: "About us",
  description: "Banji Alabi & Co is a law firm with a particular strength in real estate and conveyancing.",
};

const principles = [
  {
    title: "Plain advice",
    text: "We explain the law in language a client can act on, and we tell you when the answer is not what you hoped for.",
  },
  {
    title: "Fees in writing",
    text: "Before work begins, you receive our fees in writing, kept separate from the other costs of your transaction or case.",
  },
  {
    title: "Careful documents",
    text: "Agreements, deeds and pleadings are checked against the facts and the law before they leave the office.",
  },
  {
    title: "Prompt communication",
    text: "We return calls and messages, and we report progress without being chased.",
  },
];

export default function About() {
  return (
    <>
      <PageHeader
        title="A full-service firm with a strong hand in property."
        intro="Banji Alabi & Co advises individuals, families and businesses across a range of legal fields, with real estate and conveyancing at the centre of its practice."
      />

      <section className="py-20 md:py-24">
        <div className="wrap grid gap-12 lg:grid-cols-12">
          <div className="prose-legal text-lg text-muted lg:col-span-7">
            <p>
              Banji Alabi, Esq. is a Barrister and Solicitor of the Supreme Court of Nigeria and the principal partner of Banji Alabi &amp; Co, headquartered in Lekki, Lagos. The firm has a special bias for real estate, revenue generation and tax consultancy, and oil and gas advisory.
            </p>
            <p>
              Before founding the firm he spent 24 years at Chevron Nigeria Limited, from 1990 to 2014. He is a member of the Nigerian Bar Association, the Chartered Institute of Taxation of Nigeria and the Lagos Polo Club, and has completed executive training in law, oil and gas, taxation and leadership in the United States, the United Kingdom and Dubai.
            </p>
            <p>
              He was the first alumnus appointed Chairman of the Governing Council of Rufus Giwa Polytechnic, Owo, and the first to be reappointed for a second term. His submission to the National Conference argued for true federalism and resource control.
            </p>
            <p>
              The firm was established with other seasoned professionals, including his wife and co-principal, Mrs Omolola Banji-Alabi, a Chartered Banker.
            </p>
          </div>
          <div className="lg:col-span-5">
            <Portrait className="aspect-square w-full" />
            <p className="mt-3 text-sm text-muted">Banji Alabi, principal partner</p>
          </div>
        </div>
      </section>

      <section className="bg-limestone py-20 md:py-24">
        <div className="wrap">
          <h2 className="text-4xl md:text-5xl">How we work</h2>
          <dl className="mt-12 grid gap-x-12 gap-y-10 md:grid-cols-2">
            {principles.map((p) => (
              <div key={p.title} className="border-t-2 border-brass pt-5">
                <dt className="font-display text-2xl">{p.title}</dt>
                <dd className="mt-2 max-w-md text-muted">{p.text}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="py-20">
        <div className="wrap flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <h2 className="text-3xl md:text-4xl">Meet the people handling your matter.</h2>
          <div className="flex gap-3">
            <Link href="/team" className="btn btn-ink">Our team</Link>
            <Link href="/contact" className="btn btn-outline-ink">Contact us</Link>
          </div>
        </div>
      </section>
    </>
  );
}
