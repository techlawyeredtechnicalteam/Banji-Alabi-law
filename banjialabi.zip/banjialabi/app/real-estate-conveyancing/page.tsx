import type { Metadata } from "next";
import Link from "next/link";
import PageHeader from "@/components/PageHeader";
import EstatesShowcase from "@/components/EstatesShowcase";
import MediaGallery from "@/components/MediaGallery";
import { WhatsAppIcon } from "@/components/Icons";
import { whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Real estate and conveyancing",
  description:
    "Title investigation, documentation and registration for land and property transactions, with conveyancing fees set out separately from property costs.",
};

const services = [
  { title: "Property acquisition and sale", text: "Negotiating purchases and sales, with due diligence for buyers and clean documentation for sellers." },
  { title: "Conveyancing", text: "Preparing and completing the transfer of an interest in land, from searches to registration." },
  { title: "Searches and due diligence", text: "Confirming ownership, encumbrances and the validity of the title documents." },
  { title: "Perfection and registration of titles", text: "Following up the consents and registrations that make a transfer effective." },
  { title: "Commercial property transactions", text: "Offices, retail and mixed-use property for companies and investors." },
  { title: "Property finance and mortgages", text: "Security, mortgages and facilities backed by real estate." },
  { title: "Property investment agreements", text: "Structuring and documenting investments in land and buildings." },
  { title: "Joint ventures and builder-buyer agreements", text: "Agreements between landowners, developers and purchasers." },
  { title: "Property development law", text: "Approvals, development agreements and regulatory compliance." },
  { title: "Leasehold and tenancy agreements", text: "Leases and tenancies for landlords, tenants and managers." },
  { title: "Estates management advisory", text: "Advice for estate managers and residents' associations." },
  { title: "Facilities management", text: "Contracts and compliance for those who run buildings and estates." },
];

const steps = [
  { title: "Instruction and fee agreement", text: "We confirm what you need and send our conveyancing fees in writing." },
  { title: "Title investigation", text: "We search the registry and examine the seller’s documents of title." },
  { title: "Survey and site verification", text: "We check the survey plan against the land and look for acquisitions or competing claims." },
  { title: "Documentation", text: "We prepare or review the sale agreement and the deed of assignment." },
  { title: "Consent, stamping and registration", text: "Where the law requires it, we apply for consent, pay duties and register the transfer." },
  { title: "Completion", text: "You receive your executed documents, with a clear record of what was done." },
];

export default function RealEstate() {
  return (
    <>
      <PageHeader
        title="Real estate and conveyancing"
        intro="The heart of our practice. We act for property developers, mortgage companies, purchasers, tenants, landowners and managers across the real estate chain."
      >
        <div className="flex flex-wrap gap-3">
          <Link href="/contact?area=Real%20estate%20and%20conveyancing" className="btn btn-brass">Enquire about a property matter</Link>
          <a href={whatsappLink("Hello, I would like to ask about a real estate or conveyancing matter.")} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light">
            <WhatsAppIcon size={18} /> WhatsApp us
          </a>
        </div>
      </PageHeader>

      {/* Fee disclaimer */}
      <section className="py-12 md:py-16">
        <div className="wrap">
          <aside className="border-l-4 border-brass bg-limestone p-6 md:p-8" aria-labelledby="fees-note">
            <h2 id="fees-note" className="text-2xl md:text-3xl">Property costs and conveyancing fees are separate</h2>
            <div className="prose-legal mt-3 text-muted">
              <p>
                The cost of a property transaction, including the purchase price and any charges, taxes or fees payable on the property itself, is distinct from our conveyancing fees.
              </p>
              <p>
                Our conveyancing fees cover only the legal work we do for you. We confirm them in writing before we begin, so you know what you are paying for and to whom.
              </p>
            </div>
          </aside>
        </div>
      </section>

      {/* Services */}
      <section className="pb-20 md:pb-24">
        <div className="wrap">
          <h2 className="text-4xl md:text-5xl">What we do</h2>
          <ul className="mt-10 grid gap-x-12 gap-y-8 md:grid-cols-2">
            {services.map((s) => (
              <li key={s.title} className="border-t border-ink/20 pt-5">
                <h3 className="text-2xl">{s.title}</h3>
                <p className="mt-2 text-muted">{s.text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Process */}
      <section className="bg-ink py-20 text-paper md:py-24">
        <div className="wrap">
          <h2 className="text-4xl md:text-5xl">How a conveyance runs</h2>
          <p className="mt-4 max-w-xl text-paper/70">The usual sequence for a land transfer. Your matter may need more or fewer steps.</p>
          <ol className="mt-12 grid gap-x-10 gap-y-10 md:grid-cols-2 lg:grid-cols-3">
            {steps.map((s, i) => (
              <li key={s.title} className="flex gap-5">
                <span className="font-display text-5xl leading-none text-brass-light" aria-hidden="true">{i + 1}</span>
                <div>
                  <h3 className="text-xl">{s.title}</h3>
                  <p className="mt-2 text-[0.97rem] text-paper/70">{s.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <EstatesShowcase />

      {/* Properties gallery */}
      <section className="py-20 md:py-24">
        <div className="wrap">
          <h2 className="text-4xl md:text-5xl">Properties and sites</h2>
          <p className="mt-4 max-w-xl text-muted">A look at land and properties from our work.</p>
          <div className="mt-10">
            <MediaGallery folder="properties" />
          </div>
        </div>
      </section>

      <section className="bg-limestone py-16">
        <div className="wrap flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <h2 className="max-w-xl text-3xl md:text-4xl">Planning to buy, sell or develop land? Speak to us before you pay.</h2>
          <Link href="/contact?area=Real%20estate%20and%20conveyancing" className="btn btn-ink">Make an enquiry</Link>
        </div>
      </section>
    </>
  );
}
