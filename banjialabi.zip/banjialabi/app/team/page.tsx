import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import Portrait from "@/components/Portrait";
import { team } from "@/lib/team";

export const metadata: Metadata = {
  title: "Our team",
  description: "The lawyers and staff of Banji Alabi & Co.",
};

export default function Team() {
  return (
    <>
      <PageHeader title="Our team" intro="The people who will handle your matter." />
      <section className="py-16 md:py-20">
        <div className="wrap">
          <ul className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {team.map((m) => (
              <li key={m.slug}>
                <Portrait file={m.photo ?? m.slug} name={m.name} className="aspect-square w-full" />
                <h2 className="mt-5 text-2xl">{m.name}</h2>
                <p className="text-brass-deep">{m.role}</p>
                <p className="mt-3 text-muted">{m.bio}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
}
