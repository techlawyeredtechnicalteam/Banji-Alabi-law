import Link from "next/link";
import EstatesShowcase from "@/components/EstatesShowcase";
import SurveyMotif from "@/components/SurveyMotif";
import MediaGallery from "@/components/MediaGallery";
import Portrait from "@/components/Portrait";
import { ChevronRight, WhatsAppIcon, PhoneIcon } from "@/components/Icons";
import { practiceAreas } from "@/lib/practice-areas";
import { insights } from "@/lib/insights";
import { site, whatsappLink } from "@/lib/site";

const fmt = (iso: string) =>
  new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-ink text-paper">
        <div className="wrap grid items-center gap-10 py-16 md:py-24 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <h1 className="text-[2.75rem] md:text-[4.5rem]">
              Your land, your title, properly secured.
            </h1>
            <p className="mt-7 max-w-xl text-lg text-paper/75">
              Banji Alabi &amp; Co is a Lekki law firm with a deep practice in real estate and conveyancing, and the breadth to advise on tax, oil and gas, litigation, maritime and finance matters.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link href="/contact" className="btn btn-brass">Make an enquiry</Link>
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="btn btn-outline-light">
                <WhatsAppIcon size={18} /> Chat on WhatsApp
              </a>
            </div>
          </div>
          <div className="lg:col-span-5">
            <SurveyMotif className="mx-auto w-full max-w-md lg:max-w-none" />
          </div>
        </div>
      </section>

      {/* Real estate and conveyancing */}
      <section className="py-20 md:py-28">
        <div className="wrap grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <h2 className="text-4xl md:text-5xl">Real estate and conveyancing</h2>
            <div className="prose-legal mt-6 text-muted">
              <p>
                Buying, selling or developing land involves more than a signature. We check the title, verify the survey, prepare the documents and see the transfer through to registration.
              </p>
              <p>
                Property transaction costs and our conveyancing fees are separate, and we set out our fees in writing before we start.
              </p>
            </div>
            <Link href="/real-estate-conveyancing" className="btn btn-outline-ink mt-4">
              See how we handle property
            </Link>
          </div>
          <div className="lg:col-span-7">
            <MediaGallery folder="properties" limit={4} />
          </div>
        </div>
      </section>

      <EstatesShowcase />

      {/* Practice areas index */}
      <section className="bg-limestone py-20 md:py-28">
        <div className="wrap">
          <h2 className="max-w-2xl text-4xl md:text-5xl">Where we practise</h2>
          <ul className="mt-12 border-t border-ink/20">
            {practiceAreas.map((p) => (
              <li key={p.slug} className="border-b border-ink/20">
                <Link
                  href={`/practice-areas/${p.slug}`}
                  className="group grid items-center gap-2 py-6 md:grid-cols-12 md:gap-8"
                >
                  <span className="font-display text-2xl md:col-span-5 md:text-[1.75rem]">{p.title}</span>
                  <span className="text-muted md:col-span-6">{p.summary}</span>
                  <span className="hidden justify-self-end text-brass-deep transition-transform group-hover:translate-x-1 md:block">
                    <ChevronRight size={22} />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* About */}
      <section className="py-20 md:py-28">
        <div className="wrap grid items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Portrait className="aspect-square w-full max-w-md" />
          </div>
          <div className="lg:col-span-7">
            <h2 className="text-4xl md:text-5xl">Led by Banji Alabi</h2>
            <div className="prose-legal mt-6 text-muted">
              <p>
                The firm is built around a simple idea: clients should understand where their matter stands, what it will cost, and what happens next.
              </p>
              <p>
                A Barrister and Solicitor with 24 years at Chevron Nigeria Limited behind him, Mr Alabi leads a firm with a special bias for real estate, tax and revenue consultancy, and oil and gas advisory.
              </p>
            </div>
            <Link href="/about" className="btn btn-outline-ink mt-4">About the firm</Link>
          </div>
        </div>
      </section>

      {/* Insights */}
      <section className="border-t border-ink/10 py-20 md:py-28">
        <div className="wrap">
          <div className="flex items-end justify-between gap-6">
            <h2 className="text-4xl md:text-5xl">Insights</h2>
            <Link href="/insights" className="hidden font-semibold text-brass-deep hover:underline md:block">
              All articles
            </Link>
          </div>
          <ul className="mt-10 grid gap-10 md:grid-cols-3">
            {insights.slice(0, 3).map((i) => (
              <li key={i.slug}>
                <p className="text-sm text-muted">{i.category}, {fmt(i.date)}</p>
                <h3 className="mt-2 text-2xl">
                  <Link href={`/insights/${i.slug}`} className="hover:text-brass-deep">{i.title}</Link>
                </h3>
                <p className="mt-3 text-muted">{i.excerpt}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Contact band */}
      <section className="bg-navy text-paper">
        <div className="wrap flex flex-col items-start justify-between gap-8 py-16 md:flex-row md:items-center">
          <div>
            <h2 className="text-3xl md:text-4xl">Speak to us about your matter.</h2>
            <p className="mt-3 text-paper/70">Call, message on WhatsApp or send a written enquiry.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <a href={site.phoneHref} className="btn btn-brass"><PhoneIcon /> {site.phone}</a>
            <Link href="/contact" className="btn btn-outline-light">Send an enquiry</Link>
          </div>
        </div>
      </section>
    </>
  );
}
