import type { Metadata, Viewport } from "next";
import "@fontsource-variable/newsreader/opsz.css";
import "@fontsource-variable/instrument-sans";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Logo from "@/components/Logo";
import WhatsAppButton from "@/components/WhatsAppButton";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Banji Alabi & Co | Real estate, conveyancing and commercial lawyers",
    template: "%s | Banji Alabi & Co",
  },
  description:
    "Banji Alabi & Co advises on real estate and conveyancing, litigation, banking, aviation, maritime and corporate law.",
  openGraph: {
    siteName: site.name,
    type: "website",
    locale: "en_NG",
  },
};

export const viewport: Viewport = {
  themeColor: "#0e1a2b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "LegalService",
    name: site.name,
    url: site.url,
    telephone: site.phone,
    email: site.email,
    areaServed: "NG",
  };

  return (
    <html lang="en-NG">
      <body>
        <a
          href="#main"
          className="absolute left-4 top-4 z-[60] -translate-y-24 bg-brass px-4 py-2 font-semibold text-ink focus:translate-y-0"
        >
          Skip to content
        </a>
        <Header logo={<Logo height={48} />} />
        <main id="main">{children}</main>
        <Footer />
        <WhatsAppButton />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </body>
    </html>
  );
}
