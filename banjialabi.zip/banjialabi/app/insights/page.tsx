import type { Metadata } from "next";
import Link from "next/link";
import PageHeader from "@/components/PageHeader";
import { insights } from "@/lib/insights";

export const metadata: Metadata = {
  title: "Insights",
  description: "Short, practical articles on property, conveyancing and the law.",
};

const fmt = (iso: string) =>
  new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

export default function Insights() {
  return (
    <>
      <PageHeader title="Insights" intro="Short, practical articles on property, conveyancing and the law." />
      <section className="py-16 md:py-20">
        <div className="wrap">
          <ul className="divide-y divide-ink/15 border-y border-ink/15">
            {insights.map((i) => (
              <li key={i.slug}>
                <Link href={`/insights/${i.slug}`} className="group grid gap-3 py-8 md:grid-cols-12 md:gap-8">
                  <p className="text-sm text-muted md:col-span-3">{i.category}<br />{fmt(i.date)}</p>
                  <div className="md:col-span-9">
                    <h2 className="text-3xl group-hover:text-brass-deep">{i.title}</h2>
                    <p className="mt-2 max-w-2xl text-muted">{i.excerpt}</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
}
