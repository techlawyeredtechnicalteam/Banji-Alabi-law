import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getInsight, insights } from "@/lib/insights";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return insights.map((i) => ({ slug: i.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = getInsight(slug);
  return post ? { title: post.title, description: post.excerpt } : {};
}

export default async function InsightPage({ params }: Props) {
  const { slug } = await params;
  const post = getInsight(slug);
  if (!post) notFound();

  return (
    <article className="py-16 md:py-24">
      <div className="wrap">
        <p className="text-sm text-muted">
          {post.category}, {new Date(post.date).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
        </p>
        <h1 className="mt-3 max-w-3xl text-4xl md:text-6xl">{post.title}</h1>
        <div className="prose-legal mt-10 text-lg">
          {post.body.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
        <div className="mt-12 flex flex-wrap gap-3">
          <Link href="/contact" className="btn btn-ink">Ask us about your matter</Link>
          <Link href="/insights" className="btn btn-outline-ink">All insights</Link>
        </div>
      </div>
    </article>
  );
}
