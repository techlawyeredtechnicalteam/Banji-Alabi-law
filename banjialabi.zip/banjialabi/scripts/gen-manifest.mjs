// Lists the files in /public at build time. Cloudflare Workers have no file system,
// so the site reads this list instead of scanning folders while it runs.
import fs from "node:fs";
import path from "node:path";

const root = path.join(process.cwd(), "public");
const out = [];
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    if (name.startsWith(".")) continue;
    const full = path.join(dir, name);
    if (fs.statSync(full).isDirectory()) walk(full);
    else out.push(path.relative(root, full).split(path.sep).join("/"));
  }
}
if (fs.existsSync(root)) walk(root);
out.sort();
fs.mkdirSync(path.join(process.cwd(), "lib"), { recursive: true });
fs.writeFileSync(path.join(process.cwd(), "lib", "manifest.json"), JSON.stringify(out, null, 2));
console.log(`manifest: ${out.length} public files`);
